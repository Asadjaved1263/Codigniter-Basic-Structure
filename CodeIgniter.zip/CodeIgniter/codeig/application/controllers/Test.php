<?php 
   class Test extends CI_Controller {
  
      public function index() { 
         echo "Index method from TestFile!"; 
      } 

      public function check() { 
        echo "Check method from TestFile!"; 
     } 
   } 
?>